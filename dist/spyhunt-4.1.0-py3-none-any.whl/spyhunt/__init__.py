"""Modernised Spyhunt toolkit."""

from .main import main, run, parse_ports
from .scanners import (
    DEFAULT_SUBDOMAIN_PREFIXES,
    HttpScanResult,
    HttpScanner,
    PortScanResult,
    PortScanner,
    ResolvedSubdomain,
    SubdomainScanResult,
    SubdomainScanner,
)

__all__ = [
    "main",
    "run",
    "parse_ports",
    "HttpScanResult",
    "HttpScanner",
    "PortScanResult",
    "PortScanner",
    "SubdomainScanner",
    "SubdomainScanResult",
    "ResolvedSubdomain",
    "DEFAULT_SUBDOMAIN_PREFIXES",
]
