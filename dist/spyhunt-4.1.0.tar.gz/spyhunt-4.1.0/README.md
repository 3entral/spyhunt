# Spyhunt (modern refactor)

This repository contains a modernised and fully tested refactor of the original
Spyhunt reconnaissance toolkit. The legacy single-file implementation has been
split into focused modules, given type hints and tests, and wrapped in a small
command line interface that provides reliable, inspectable results.

The refactor keeps the spirit of the project—fast reconnaissance utilities—while
making the codebase approachable for further contributions. The HTTP and TCP
scanners are implemented with asynchronous I/O so that they scale well and are
easily testable.

## Features

- **HTTP scanner** powered by `aiohttp` with TLS control, redirect handling and
  lightweight technology fingerprinting (based on headers and simple body
  heuristics).
- **TCP port scanner** using asynchronous socket connections with configurable
  concurrency and timeouts.
- **Subdomain enumerator** that resolves common prefixes concurrently and can
  be customised with user supplied wordlists.
- **Consistent result format**: both scanners return dataclass based results
  that can be serialised to JSON or printed as human readable text.
- **Structured CLI**: sub-commands make it clear which capability is being
  invoked and the output format can be customised or written directly to disk.
- **Automated tests** ensuring that the scanners and CLI behaviour remain
  reliable.

## Installation

Create a virtual environment and install the package in editable mode:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

The CLI entry point `spyhunt` will be available after installation.

## Usage

### Inspect an HTTP endpoint

```bash
spyhunt http https://example.com --format text
```

Important options:

- `--timeout` – request timeout in seconds (default `10`).
- `--no-redirects` – disable following redirects.
- `--insecure` – do not validate TLS certificates (useful for testing only).
- `--hint` – provide manual technology hints; can be repeated.
- `--format` – choose between `json` and `text` output.
- `--output` – write the JSON representation to a file in addition to STDOUT.

### Scan TCP ports

```bash
spyhunt ports 192.0.2.10 --ports 22,80,443,8000-8100 --timeout 1 --concurrency 200
```

Options:

- `--ports` – comma separated list or range of ports (`80,443,8000-8100`).
- `--timeout` – connection timeout per port (default `3`).
- `--concurrency` – number of in-flight connection attempts (default `100`).

### Enumerate subdomains

```bash
spyhunt subdomains example.com --format text --include-root
```

Options:

- `--include-root` – also include the apex domain in the results.
- `--wordlist` – load prefixes from a custom file (one prefix per line).
- `--timeout` – DNS resolution timeout per candidate (default `2`).
- `--concurrency` – number of concurrent DNS lookups (default `50`).

## Development workflow

Run the automated test-suite before submitting changes:

```bash
python -m pip install -r requirements.txt
pytest
```

The tests spin up local HTTP and TCP servers, so they complete quickly and do
not depend on external infrastructure.

## Building distributions

The project metadata lives in `pyproject.toml` and follows the modern PyPI
build configuration. To create a source distribution and wheel run:

```bash
python -m pip install build
python -m build
```

The generated archives are written to the `dist/` directory and are ready to be
uploaded with `twine` or another publishing workflow.

## Extending the tool

New scanners can be implemented by subclassing
`spyhunt.scanners.base.Scanner` and returning a dataclass result that inherits
from `spyhunt.scanners.base.ScanResult`. The CLI can then register a new
sub-command that instantiates and executes the scanner. This structure keeps the
code modular and easy to reason about, enabling contributions to focus on
individual features without editing a monolithic script.

